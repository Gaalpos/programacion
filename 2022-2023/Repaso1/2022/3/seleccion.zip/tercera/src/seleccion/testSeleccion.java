package seleccion;

import java.util.ArrayList;

public class testSeleccion {

	// ArrayList de objetos Seleccion. Independientemente de
	// la clase hija a la que pertenezca el objeto
	public static ArrayList<Seleccion> integrantes = new ArrayList<Seleccion>();

	public static void main(String[] args) {

		Seleccion delBosque = new Entrenador(1, "Vicente", "Del Bosque", 60, "284EZ89");
		Seleccion iniesta = new Futbolista(2, "Andres", "Iniesta", 29, 6, "Interior Derecho");
		Seleccion raulMartinez = new Masajista(3, "Ra�l", "Martinez", 41, "Licenciado en " + "Fisioterapia", 18);

		integrantes.add(delBosque);
		integrantes.add(iniesta);
		integrantes.add(raulMartinez);

		// probamos metodo concentrarse
		for (Seleccion s : integrantes) {
			System.out.println(s.toString());
			s.Concentrarse();
		}
		// probar metodo viajar
		for (Seleccion s : integrantes) {
			System.out.println(s.toString());
			s.Viajar();
		}
		for (Seleccion s : integrantes) {
			// entrenador
			if (s instanceof Entrenador) {
				System.out.println(s.toString());
				((Entrenador) s).dirigirPartido();
				((Entrenador) s).dirigirEntreno();
			}
			// futbolista
			if (s instanceof Futbolista) {
				System.out.println(s.toString());
				((Futbolista) s).jugarPartido();
				((Futbolista) s).entrenar();
			}
			// masajista
			if (s instanceof Masajista) {
				System.out.println(s.toString());
				((Masajista) s).darMasaje();
			}
		}
	}

}
