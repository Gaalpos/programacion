package sol5A;

public class TestCine {

	public static void main(String[] args) {
		
		ConteoPersonas contador = new ConteoPersonas();
		ConteoPersonas.menu();
	}
}
