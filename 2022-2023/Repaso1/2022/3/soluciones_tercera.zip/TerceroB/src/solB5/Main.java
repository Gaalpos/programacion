package solB5;

public class Main {
	public static void main(String[] args) {
		Logica monopoly = new Logica();
		monopoly.menu();
	}
}
