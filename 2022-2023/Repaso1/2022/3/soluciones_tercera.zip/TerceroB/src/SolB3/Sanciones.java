package SolB3;

public interface Sanciones {
	double MULTA_MAXIMA=10.000;
	String aumentar(double cuanto);
	String disminuir(double cuanto);

}
